/**
 * 
 */
package Model;

/**
 * @author lily
 *
 */
public interface StatisticsInterface {
	public void findlow(Student [] a) ;
	  
	 
	  public void findhigh(Student [] a);

	  public void findavg(Student [] a);
	  
	  
}
