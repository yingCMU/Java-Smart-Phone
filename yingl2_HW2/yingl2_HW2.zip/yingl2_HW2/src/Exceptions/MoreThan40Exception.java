package Exceptions;

public class MoreThan40Exception  extends Exception {
	private int errorno;
	private String errormsg;
	public MoreThan40Exception (String message) {
		
		super(message);
		this.errormsg = message;
	}
	
	public MoreThan40Exception (int errorno) {
		super();
		this.errorno = errorno;
		
	}
	public MoreThan40Exception (int errorno, String errormsg) {
		super();
		this.errorno = errorno;
		this.errormsg = errormsg;
		
	}
	public int getErrorno() {
		return errorno;
	}
	public void setErrorno(int errorno) {
		this.errorno = errorno;
	}
	public String getErrormsg() {
		return errormsg;
	}
	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}
}